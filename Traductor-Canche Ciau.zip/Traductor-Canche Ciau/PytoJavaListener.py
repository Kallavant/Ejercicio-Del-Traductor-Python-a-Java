# Generated from PytoJava.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .PytoJavaParser import PytoJavaParser
else:
    from PytoJavaParser import PytoJavaParser

# This class defines a complete listener for a parse tree produced by PytoJavaParser.
class PytoJavaListener(ParseTreeListener):

    # Enter a parse tree produced by PytoJavaParser#pyton_line.
    def enterPyton_line(self, ctx:PytoJavaParser.Pyton_lineContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#pyton_line.
    def exitPyton_line(self, ctx:PytoJavaParser.Pyton_lineContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#funcion.
    def enterFuncion(self, ctx:PytoJavaParser.FuncionContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#funcion.
    def exitFuncion(self, ctx:PytoJavaParser.FuncionContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#parametros.
    def enterParametros(self, ctx:PytoJavaParser.ParametrosContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#parametros.
    def exitParametros(self, ctx:PytoJavaParser.ParametrosContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#cuerpo.
    def enterCuerpo(self, ctx:PytoJavaParser.CuerpoContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#cuerpo.
    def exitCuerpo(self, ctx:PytoJavaParser.CuerpoContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#statement.
    def enterStatement(self, ctx:PytoJavaParser.StatementContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#statement.
    def exitStatement(self, ctx:PytoJavaParser.StatementContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#expresion.
    def enterExpresion(self, ctx:PytoJavaParser.ExpresionContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#expresion.
    def exitExpresion(self, ctx:PytoJavaParser.ExpresionContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#term.
    def enterTerm(self, ctx:PytoJavaParser.TermContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#term.
    def exitTerm(self, ctx:PytoJavaParser.TermContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#factor.
    def enterFactor(self, ctx:PytoJavaParser.FactorContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#factor.
    def exitFactor(self, ctx:PytoJavaParser.FactorContext):
        pass


    # Enter a parse tree produced by PytoJavaParser#print_java.
    def enterPrint_java(self, ctx:PytoJavaParser.Print_javaContext):
        pass

    # Exit a parse tree produced by PytoJavaParser#print_java.
    def exitPrint_java(self, ctx:PytoJavaParser.Print_javaContext):
        pass



del PytoJavaParser