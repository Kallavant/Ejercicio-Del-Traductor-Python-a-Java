public class Multiplicacion {
    public static int multiplica(int a, int b) {
        int resul = a * b - a;
        return resul;
    }

    public static void main(String[] args) {
        System.out.println(multiplica(5, 6));
    }
}